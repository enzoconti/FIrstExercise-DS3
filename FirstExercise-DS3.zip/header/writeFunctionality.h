#ifndef WRITEFUNCTIONALITY_H
#define WRITEFUNCTIONALITY_H

#include <stdio.h>
#include <stdlib.h>
#include "global_definitions.h"

void writeFile(char*, int nRegister);

void writeRegister(FILE *fp);

#endif